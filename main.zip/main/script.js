document.addEventListener('DOMContentLoaded', function() {
    const seatMap = document.querySelector('.seat-map');
    const confirmButton = document.getElementById('confirm-selection');
    const selectedSeatsElement = document.getElementById('selected-seats');
    const totalPriceElement = document.getElementById('total-price');
    const hallNumberElement = document.getElementById('hall-number');
    const showTimeElement = document.getElementById('show-time');

    const rows = 9; // Количество рядов
    const seatsPerRow = 12; // Количество мест в ряду
    const seatPrice = 250; // Цена за одно место
    let selectedSeats = []; // Массив для хранения выбранных мест

    // Заполняем информацию о зале и времени
    hallNumberElement.textContent = '1';
    showTimeElement.textContent = '19:30';

    // Генерация карты мест
    for (let i = 0; i < rows; i++) {
        const row = document.createElement('div');
        row.classList.add('seat-row');
        for (let j = 0; j < seatsPerRow; j++) {
            const seat = document.createElement('div');
            seat.classList.add('seat');
            seat.dataset.row = i + 1; // Устанавливаем номер ряда
            seat.dataset.seat = j + 1; // Устанавливаем номер места
            seat.addEventListener('click', toggleSeat); // Добавляем обработчик клика
            row.appendChild(seat);
        }
        seatMap.appendChild(row);
    }

    // Функция для переключения состояния места
    function toggleSeat(event) {
        const seat = event.target;
        if (!seat.classList.contains('occupied')) { // Проверяем, не занято ли место
            seat.classList.toggle('selected'); // Переключаем класс 'selected'
            updateSelectedSeats(); // Обновляем список выбранных мест
        }
    }

    // Функция для обновления списка выбранных мест и общей стоимости
    function updateSelectedSeats() {
        selectedSeats = Array.from(document.querySelectorAll('.seat.selected')).map(seat => ({
            row: seat.dataset.row,
            seat: seat.dataset.seat
        }));
        
        // Проверка на наличие выбранных мест
        if (selectedSeats.length === 0) {
            selectedSeatsElement.textContent = 'Не выбрано'; // Если нет выбранных мест
        } else {
            const seatList = selectedSeats.map(seat => `Ряд ${seat.row}, Место ${seat.seat}`).join('; ');
            selectedSeatsElement.textContent = seatList; // Обновляем отображение выбранных мест
        }
        
        const totalPrice = selectedSeats.length * seatPrice; // Вычисляем общую стоимость
        totalPriceElement.textContent = totalPrice; // Обновляем отображение общей стоимости
    }

    // Обработчик клика по кнопке подтверждения
    confirmButton.addEventListener('click', function() {
        if (selectedSeats.length > 0) {
            alert('Места забронированы: ' + selectedSeatsElement.textContent);
            // Здесь можно добавить логику для отправки данных на сервер
        } else {
            alert('Пожалуйста, выберите хотя бы одно место.'); // Сообщение, если места не выбраны
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.movie-slide');
    let currentSlide = 0;

    function showSlide(index) {
        slides[currentSlide].classList.remove('active');
        slides[index].classList.add('active');
        currentSlide = index;
    }

    function nextSlide() {
        let next = (currentSlide + 1) % slides.length;
        showSlide(next);
    }

    // Показываем первый слайд
    showSlide(0);

    // Меняем слайд каждые 5 секунд
    setInterval(nextSlide, 5000);
});

document.getElementById('review-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('review-name').value;
    const text = document.getElementById('review-text').value;

    const reviewCard = document.createElement('div');
    reviewCard.classList.add('review-card');

    const reviewName = document.createElement('h4');
    reviewName.textContent = name;

    const reviewText = document.createElement('p');
    reviewText.textContent = text;

    reviewCard.appendChild(reviewName);
    reviewCard.appendChild(reviewText);
    document.getElementById('reviews1').appendChild(reviewCard);

    // Очистка формы
    document.getElementById('review-name').value = '';
    document.getElementById('review-text').value = '';
});

document.addEventListener('DOMContentLoaded', function () {
    const navbarToggle = document.getElementById('navbar-toggle');
    const navbarLinks = document.getElementById('navbar-links');
    const closeMenu = document.getElementById('close-menu');

    navbarToggle.addEventListener('click', function () {
        navbarLinks.classList.add('active');
    });

    closeMenu.addEventListener('click', function () {
        navbarLinks.classList.remove('active');
    });

    // Закрыть меню при клике вне его
    document.addEventListener('click', function (event) {
        if (!navbarLinks.contains(event.target) && !navbarToggle.contains(event.target)) {
            navbarLinks.classList.remove('active');
        }
    });
});

function searchMovies() {
    const input = document.getElementById('search-input').value.toLowerCase(); // Получаем значение из поля ввода
    const movieList = document.getElementById('poster-container'); // Получаем список фильмов
    const movies = movieList.getElementsByClassName('poster-item'); // Получаем все элементы фильмов

    // Проходим по всем фильмам и скрываем или показываем их в зависимости от поиска
    for (let i = 0; i < movies.length; i++) {
        const title = movies[i].getAttribute('data-title').toLowerCase(); // Получаем название фильма
        if (title.includes(input)) {
            movies[i].style.display = ''; // Показываем фильм
        } else {
            movies[i].style.display = 'none'; // Скрываем фильм
        }
    }
}